package com.example.phonecall

    data class Contact(
        val name: String,
        val phoneNumber: String
    )
